    windows 系统中为提高效率请直接运行 CoolPlist.bat 批处理文件。
    
    一键自动生成 .plist 文件的工具。

        具体功能：自动生成 “图像纹理定义文件” -> “帧动画定义文件”。

        使用方法：
            一、* 自动生成项目配置文件 profile.json 。(无profile.json文件情况下须此操作)
                运行一次本脚本，将于此目录下自动生成一个profile.json文件。
                配置好 profile.json 文件，参数请参考 TexturePacker 命令行参数。（网上有）

            二、* 安装 TexturePacker 工具 
                1.下载 TexturePacker 并安装好。
                2.找到其安装目录中\bin目录。如："C:\Program Files (x86)\CodeAndWeb\TexturePacker\bin"复制并添加到“环境变量”path中。
                （此步骤无可奈何，有时间我将使用脚本完成此功能，就不用安装此工具）

            三、* python3.+ 安装
                1.下载并安装 3.+ 版本的 Python
                2.找到其安装目录。如:"C:\Python34" 复制并添加到“环境变量”path中。

            四、运行脚本
        解答：
            1. 添加体统变量方法
                [我的电脑] -(右键)-> [属性] -(window8及以上点[高级系统属性])-> [高级] -> [环境变量]

            2. “*” 表示第一次使用本工具时才需要执行，只需执行一次。


        Profile.json 文件解析：

            CoolPlist_Default : 
                -> ["AutoPackTexture"] : 自动打包纹理。
                -> ["AutoDerivedFrameAnimationFile"] : 自动生成帧动画定义文件。

            FrameAnimationDefFile : 
                -> ["UseImageTextureDefFile"] : 是否使用已有的“图像纹理定义文件”生成“帧动画定义文件”。
                -> ["AnimationUseFolderName"] : 是否使用图片资源目录结构生成“帧动画定义文件”。
            
            当 UseImageTextureDefFile == false && AnimationUseFolderName == true 时，帧动画生成规则如下：
                1、图片资源目录（TexturePacker["ImageFolder"]）。
                2、一张图片代表一个关键帧。
                3、图片资源目录及其子目录，每个目录中存在一张以上的图片即视作一个动画。
                4、动画名称即目录名称。
                5、图片命名规则："anyName_frameIndex.png"。

            当 UseImageTextureDefFile == false && AnimationUseFolderName == false 时,帧动画生成规则如下：
                1、图片资源目录（TexturePacker["ImageFolder"]）。
                2、一张图片代表一个关键帧。
                3、图片命名规则："animationName_frameIndex.png"。
                4、所有图片名称"animationName" 部分相同的图片视作同一动画中的帧，即使图片放置于不同目录。

            请看源码中详尽注释。