# -*- coding: utf-8 -*-

"""
    @Author     陈前帆 thinkingMan | sonny 
    @Mails      625936034@qq.com | chenqianfan1@163.com
    @Telephone  13670471300
    @Date       2016年7月11日
    @Version    v3.0.0
    @Description 本工具v2.5.0版本及之前版本使用的 JScript 脚本语言编写，只支持 windows 系统平台。
                由于考虑多系统平台版本支持，故而从v3.0.0版本开始使用 Python 编写。
"""


import os
import json
import re
import shutil
import plistlib
from utils.imageTextureDef import ImageTextureDef 
from utils.frameAnimationFormats import FrameAnimationFormat1
from utils.frameAnimationFormats import FrameAnimationFormat2
from utils.profile import profile # 默认配置文件。


PROFILE = "Profile.json"

# 获取文件名扩展名。
def getSuffixName(fileName):
    return os.path.splitext(fileName)[-1]


def copy(src, dst):
    """ 拷贝一个文件到指定目标 """
    if not os.path.exists(src):
        raise FileNotFoundError("No suck file of directory:'" + src + "'") 
    shutil.copy(src, dst)

def save(plistFileName, plistContent, backOldFile):
    """ 保存plist数据到指定文件。
        @param {string} plistFileName plist文件名称。
        @param {dict}  plistContent 写入 plist 文件内容。
        @param {boolean} backOldFile 是否备份就文件。
    """
    if backOldFile:
        ext = getSuffixName(plistFileName)
        name = os.path.basename(plistFileName).split(".")[0]
        path = os.path.split(plistFileName)[0]
        # MAX_COUNT = 3
        # cover = True
        # for index in range(1, MAX_COUNT,1):
        #     backupFileName = os.path.join(path, name + "(__BACK_UP_"+ str(index) + ")" + ext)
        #     if not os.path.exists(backupFileName):
        #         cover = False
        #         if os.path.exists(plistFileName):
        #             copy(plistFileName, backupFileName)
        #         break
        # if cover:
        #     backupFileName = os.path.join(path, name + "(__BACK_UP_1)" + ext)
        #     if os.path.exists(plistFileName):
        #         copy(plistFileName, backupFileName)
        # TODO : 考虑生成较多的备份文件会容易导致文件管理混乱，所以删减成一个，后续将研究下怎么备份才好。
        backupFileName = os.path.join(path, "_" + name + "(__BACK_UP)" + ext)
        if os.path.exists(plistFileName):
            copy(plistFileName, backupFileName)
            
    with open(plistFileName, "wb") as plistFile:
        # print(plistContent)
        plistlib.dump(plistContent, plistFile)





def readProFile():
    """ 读取配置文件。
    """
    print("Read the configuration file 'profile.json'!")
    global profile
    # print(id(profile))
    with open(PROFILE) as fp:
        profileJSON = json.load(fp)
        if profileJSON :
            # print(profileJSON)
            for key, value in profileJSON.items():
                if profile[key] :
                    config = profile[key]
                    for itemKey, itemValue in value.items():
                        config[itemKey] = itemValue
    # print(profile["FrameAnimationDefFile"])
    # print(id(profile))
    print("Read Complete!")


#########################
# 纹理打包工具命令行运行。
#########################
def runAutoPackTexture():
    """ 运行自动打包图像纹理。
    """
    config = profile["TexturePacker"]
    # print(config)
    commandLine = "TexturePacker "
    commandLine += " --sheet "+ config["SheetFileName"] if config["SheetFileName"] != None else ""
    commandLine += " --data " + config["DataFileName"]  if config["DataFileName"] != None else ""
    commandLine += " --format " + config["Format"] if config["Format"] != None else ""
    commandLine += " --texturepath " + config["TexturePath"] if config["TexturePath"] != None and config["TexturePath"] != "" else ""
    commandLine += " --width " + str(config["Width"]) if config["Width"] != None else ""
    commandLine += " --height " + str(config["Height"]) if config["Height"] != None else ""
    if config["MaxSize"] != None:
        commandLine += " --max-size " + str(config["MaxSize"]) if config["MaxSize"] != None else ""
    else:
        commandLine += " --max-width " + str(config["MaxWidth"]) if config["MaxWidth"] != None else ""
        commandLine += " --max-height " + str(config["MaxHeight"]) if config["MaxHeight"] != None else ""
    
    commandLine += " --shape-padding " + str(config["ShapePadding"]) if config["ShapePadding"] != None else ""
    commandLine += " --border-padding " + str(config["BorderPadding"]) if config["BorderPadding"] != None else ""
    commandLine += " --padding " + str(config["Padding"]) if config["Padding"] != None else ""
    commandLine += " --inner-padding " + str(config["InnerPadding"]) if config["InnerPadding"] != None else ""
    commandLine += " --enable-rotation" if config["Rotation"] else " --disable-rotation"
    commandLine += " --trim-mode " + config["TrimMode"]
    commandLine += " " + config["ImageFolder"]
    print("Running Command Line ->: " + commandLine)
    os.system(commandLine) # 运行打包图像纹理。


def isAnimationSprite(fileName):
    """ 检查是否是一个动画的精灵。
        文件名是格式："animationName_FrameIndex";
        @param {str} fileName 
    """  
    strSplit = fileName.split("_")
    # print("isAnimationSprite(", fileName, ")")
    # print("isAnimationSprite(fileName", strSplit)
    if len(strSplit) < 2:
        return False
    return strSplit.pop().split(".")[0].isnumeric()


def frameSort(frames):
    """ 对帧进行排序。防止生成的动画帧序列不对。
        @param {list} frames 帧数组。
    """
    def cmp(item1):
        spriteframe1 = None
        if isinstance(item1, str):
            spriteframe1 = item1
        else :
            spriteframe1 = item1["spriteframe"]
        strSplit1 = spriteframe1.split(".")[0].split("_")
        index_1 = strSplit1[len(strSplit1) - 1]
        return index_1
    frames.sort(key=cmp)


def inferToAnimationName(fileName):
    """ 根据文件名推断出其对应的动画的名称。
        @param {String} fileName 文件名称。 "animatioin_1.png" | "folder/animation_1.png"
        @returns {String|None}
    """
    # print(fileName)
    animationName = None
    endIndex = -1
    startIndex = 0
    if isAnimationUseFolderName() :
        endIndex = fileName.rfind("/")
        if endIndex !=-1 :
            startIndex = fileName.rfind("/", endIndex- 1)
        else :
            endIndex = fileName.rfind("_")
        
        if startIndex == -1:
            startIndex = 0
        else:
            startIndex += 1
        
        if endIndex != -1 :
            animationName = fileName[startIndex: endIndex]
    else:
        endIndex = fileName.rfind("_")
        startIndex = fileName.rfind("/")
        if startIndex == -1 :
            startIndex = 0
        else:
            startIndex += 1
        if endIndex != -1 :
            animationName = fileName[startIndex: endIndex]
    return animationName

def inferToFrameIndex(fileName):
    """ 根据文件名推断出其对应动画的帧索引。
        @param {str} fileName 文件名称。
        @return {int|None}
    """
    fileName = fileName.split(".")[0] # 排除掉扩展名。
    index = fileName.rfind("_")
    frameIndex = -1
    if index != -1 :
        indexStr = fileName[index + 1:]
        try :
            frameIndex = int(indexStr)
        except :
            return frameIndex
    return frameIndex


def isSupportedFileType(fileName):
    """ 是否所支持文件格式。
        @param {str} fileName
        @returns {boolean}
    """
    suffixName = getSuffixName(fileName)
    for value in profile["CoolPlist_Default"]["SupportedFileTypes"]:
        if value == suffixName or "." + value == suffixName: 
            return True
    return False

def isPlistFileType(fileName):
    """ 是否是Plist文件类型。
        @param {String} fileName 文件名 如：aaaa.plist
        @returns {boolean}
    """
    # print(getSuffixName(fileName))
    return getSuffixName(fileName) == ".plist"

def getIgnoreFramesRegexp():
    """ 获取要忽略的帧名的正则表达式 """
    return profile["FrameAnimationDefFile"]["IgnoreFramesRegexp"]


def isAnimationUseFolderName():
    global profile
    # print("isAnimationUseFolderName()", id(profile))
    return profile["FrameAnimationDefFile"]["AnimationUseFolderName"]


class CoolPlist():
    """ 一键自动生成 .plist 文件的工具。

        具体功能：自动生成 “图像纹理定义文件” -> “帧动画定义文件”。

        使用环境: windows | linux | Mac OS

        使用方法：
            一、* 自动生成项目配置文件 profile.json 。(无profile.json文件情况下须此操作)
                运行一次本脚本，将于此目录下自动生成一个profile.json文件。
                配置好 profile.json 文件，参数请参考 TexturePacker 命令行参数。（网上有）

            二、* 安装 TexturePacker 工具 
                1.下载 TexturePacker 并安装好。
                2.找到其安装目录中\bin目录。如："C:\Program Files (x86)\CodeAndWeb\TexturePacker\bin"复制并添加到“环境变量”path中。
                （此步骤无可奈何，有时间我将使用脚本完成此功能，就不用安装此工具）

            三、* python3.+ 安装
                1.下载并安装 3.+ 版本的 Python
                2.找到其安装目录。如:"C:\Python34" 复制并添加到“环境变量”path中。

            四、运行脚本
        解答：
            1. 添加体统变量方法
                [我的电脑] -(右键)-> [属性] -(window8及以上点[高级系统属性])-> [高级] -> [环境变量]

            2. “*” 表示第一次使用本工具时才需要执行，只需执行一次。


        Profile.json 文件解析：

            CoolPlist_Default : 
                -> ["AutoPackTexture"] : 自动打包纹理。
                -> ["AutoDerivedFrameAnimationFile"] : 自动生成帧动画定义文件。

            FrameAnimationDefFile : 
                -> ["UseImageTextureDefFile"] : 是否使用已有的“图像纹理定义文件”生成“帧动画定义文件”。
                -> ["AnimationUseFolderName"] : 是否使用图片资源目录结构生成“帧动画定义文件”。
            
            当 UseImageTextureDefFile == false && AnimationUseFolderName == true 时，帧动画生成规则如下：
                1、图片资源目录（TexturePacker["ImageFolder"]）。
                2、一张图片代表一个关键帧。
                3、图片资源目录及其子目录，每个目录中存在一张以上的图片即视作一个动画。
                4、动画名称即目录名称。
                5、图片命名规则："anyName_frameIndex.png"。

            当 UseImageTextureDefFile == false && AnimationUseFolderName == false 时,帧动画生成规则如下：
                1、图片资源目录（TexturePacker["ImageFolder"]）。
                2、一张图片代表一个关键帧。
                3、图片命名规则："animationName_frameIndex.png"。
                4、所有图片名称"animationName" 部分相同的图片视作同一动画中的帧，即使图片放置于不同目录。

            请看源码中详尽注释。

    """

    @classmethod
    def run(cls):
        """ 执行工具所有操作。
        """
        # 读取配置文件。
        readProFile()

        # 自动打包纹理。生成“图像纹理定义文件”，即生成sheet与data文件。
        if profile["CoolPlist_Default"]["AutoPackTexture"]:
            runAutoPackTexture()
        # 自动生成帧动画定义文件。
        config = profile["FrameAnimationDefFile"]
        if profile["CoolPlist_Default"]["AutoDerivedFrameAnimationFile"] :
            print("****** 开始生成'帧动画定义文件' *******")
            print(" Animation File Format: "+ str(config["Format"]))
            coolPlist = CoolPlist(config["Format"])
            # 自动生成“图像纹理定义文件”模式，直接读取生成的“图像纹理定义文件”来生成“帧动画定义文件”。
            if profile["CoolPlist_Default"]["AutoPackTexture"] :
                texturePacker = profile["TexturePacker"]
                if texturePacker["DataFileName"] != None:
                    coolPlist.imageTextureDefFileToAnimationPlist(texturePacker["DataFileName"])
                else :
                    coolPlist.dirToFrameAnimationPlist(texturePacker["ImageFolder"])
            else :
                # 使用图片
                texturePacker = profile["TexturePacker"]
                if config["UseImageTextureDefFile"]:
                    coolPlist.plistFolderToAnimationPlist(config["DefaultImageTextureDefFolder"])
                else:
                    coolPlist.dirToFrameAnimationPlist(texturePacker["ImageFolder"])
            print("*************************************")
        print("[***] 自动操作完成了！Y(^_^)Y [***]")


    def __init__(self, format):
        """ coolPlist = CoolPlist(1)
            @param {int} format 生成的“帧动画定义文件”格式。分1|2这两种。
        """
        self._frameAnimationDefFileFromat = 1
        self._fAnimationFormat = None
        self.setFrameAnimationDefFileFromat(format)

    def setFrameAnimationDefFileFromat(self, format):
        """ 设置生成的帧动画声明文件的格式。格式分：1|2， 两种。
            @param {int} format
        """
        # print("coolPlist setFrameAnimationDefFileFromat(" + str(format) + ")")
        self._frameAnimationDefFileFromat = format
        if format == 1:
            self._fAnimationFormat = FrameAnimationFormat1()
        elif format == 2:
            self._fAnimationFormat = FrameAnimationFormat2()

    def imageTextureDefFileToAnimationPlist(self, plistFile):
        """ 读取"图像纹理定义文件" 并生成一个"帧动画定义文件"。
            @param {String} plistFile 图像纹理定义文件完整文件名。
        """
        print("    Use SpriteSheet File : " + plistFile )
        self._fAnimationFormat.addSpritesheet(plistFile)
        
        # 将其解析为xml文档。
        plistData = self._fAnimationFormat._data

        # 将plist内容保存为一个与目标目录同名的 .plist 文件。
        save(profile["FrameAnimationDefFile"]["FileName"], plistData, profile["FrameAnimationDefFile"]["BackupOldFile"]);
        print("    Created Animation File : " + profile["FrameAnimationDefFile"]["FileName"])

    def plistFolderToAnimationPlist(self, dirPath):
        """ 读取指定目录下所有"图像纹理定义文件"，并生成为一个“帧动画定义文件”
            @param {String} dirPath plist 文件存放的目录。
        """
        if not os.path.exists(dirPath):
            raise "CoolPlist.plistFolderToAnimationPlist() 找不到路径 " + dirPath
            return
        print("    Use SpriteSheet Folder : " + dirPath )
        self._fAnimationFormat.plistFolderToAnimation(dirPath)
        # 将其解析为xml文档。
        plistData = self._fAnimationFormat._data
        # 将plist内容保存为一个与目标目录同名的 .plist 文件。
        save(profile["FrameAnimationDefFile"]["FileName"], plistData, profile["FrameAnimationDefFile"]["BackupOldFile"]);
        print("    Created Animation File : " + profile["FrameAnimationDefFile"]["FileName"])
        
    def dirToFrameAnimationPlist(self, dirPath):
        """ 通过读取目录的方式创建“帧动画定义文件”。
            生成一个与目录对应的.plist格式的“帧动画定义文件”。
            图片放置规则：
             	1、同一动画图片放置在同一个目录里边。
             	2、目录名称即是动画名称。
             	3、动画图片明格式:"animationName_frameIndex" 解释：animationName 为动画名称。frameIndex 为一个数字索引值，从"0"或者"1"开始。
            @method dirToFrameAnimationPlist
            @param {String} dirPath 目录完整路径。
        """
        if not os.path.exists(dirPath) :
            raise "CoolPlist.dirToFrameAnimationPlist() 找不到路径 " + dirPath
        print("    Use Image Folder : " + dirPath )
        self._fAnimationFormat.folderToAnimation(dirPath)
        # 将其解析为xml文档。
        plistData = self._fAnimationFormat._data
        # 将plist内容保存为一个与目标目录同名的 .plist 文件。
        save(profile["FrameAnimationDefFile"]["FileName"], plistData, profile["FrameAnimationDefFile"]["BackupOldFile"]);
        print("    Created Animation File : " + profile["FrameAnimationDefFile"]["FileName"])


# 执行本脚本时调用。
if __name__ == "__main__":
    if not os.path.exists(PROFILE):
        print("已确定您是第一次使用本工具，将为你创建配置文件!")
        print("-------- Create File 'Profile.json' --------")
        jsonStr = json.dumps(profile)
        json.dump(json.loads(jsonStr), open(PROFILE, "w"), indent=4)
        print("--------------------------------------------")
    else:
        CoolPlist.run()