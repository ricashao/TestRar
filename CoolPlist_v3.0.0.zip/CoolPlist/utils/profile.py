
# 默认配置文件。
global profile
profile = {
    "CoolPlist_Default":{
        "SupportedFileTypes":["png", "jpg"], 	# 支持的文件格式。
        "AutoPackTexture": True,        		# 自动打包纹理。生成“图像纹理定义文件”，即生成sheet(大图)与data(.plist)文件。
        "AutoDerivedFrameAnimationFile": True	# 自动推导出帧动画文件。自动检测生成的纹理文件，并自动生成“帧动画定义文件(.plist)”,当值为False的时候直接读取资源文件夹目录中文件，并推导出动画。
    },
    "TexturePacker":{
        "Version":"3.0.9",						# TexturePacker版本。
        "ImageFolder":"res", 					# 资源目录。
        # "ImageTextureFileDir" : "",				# 将生成与读取的"图像纹理定义文件"存放目录。
        "SheetFileName" : "spriteSheet/spriteSheet.png",					# 生成的图片名称。支持png,jpg,pvr,pvr.czz,pvr.gz格式
        "DataFileName" :"spriteSheet/spriteSheet.plist", 					# 生成的图像纹理定义文件.plist名称。
        "Format" : "cocos2d",					# 生成的plist格式,我们使用cocos2d格式
        "TexturePath" : "",						# 在生成的sheet文件的路径前加你。示例："--texturepath image/tower" 最终等于
        "Width" : None,							# 输出图片的宽度。
        "Height":None,							# 输出图片的高度。
        "MaxWidth":None,						# 设置输出图片的最大宽度/高度/尺寸
        "MaxHeight":None,						# 设置输出图片的最大宽度/高度/尺寸
        "MaxSize":None,							# 设置输出图片的最大宽度/高度/尺寸 相当于同时设置最大宽高。
        # "AllowFreeSize":True,					# 允许输出图片不是2的幂,以最小尺寸输出.注:这个一般开启,cocos2d-x2.0开始就已经支持图片不是2的幂了
        "ShapePadding":2,						# 图块之间缝隙的宽度,默认值是2。示例:--shape-padding 100
        "BorderPadding":2, 						# 可以理解为边框的宽度,默认值为2。示例:--border-padding 100
        "Padding":None,							# 间距,这个参数等价于上面两个参数同时同时作用.
        "InnerPadding":0,						# 试了一下,这个参数的作用应该是给每个sprite的周围加一个边框,默认值为0.注:上面的这几个参数作用都不是很大
        "Rotation":False,						# —enable-rotation/diable-rotation。注:这个很好理解,为了排版更密集些,有的图片会被旋转
        "TrimMode":"None",						# 剪裁图片,即移除图片周围的透明像素,保留原始尺寸,默认不开启)（"None"|"Trim"|"Crop"|"CropKeepPos"）。
        "ignoreFiles":None                      # 生成“图像纹理定义文件”要忽略的文件的正则表达式。
    },
    "FrameAnimationDefFile":{
        "DefaultImageTextureDefFolder" : "./spritesheet",
        "BackupOldFile" : True,					# 是否备份旧文件，很多时候，我们可能已经修改了配置文件，如果使用此工具，则很可能覆盖掉旧文件，所以，添加此属性防止出现错误。
        "UseImageTextureDefFile" : True,		# 是否是用图像纹理定义文件来推导出帧动画定义文件。
        "AnimationUseFolderName":False,     	# 动画是否是用目录名称。默认值：False，即通过分析文件名获取其对应的动画名称。（当使用图片素材目录文件推导时使用）
        "IgnoreFramesRegexp":None,				# 要忽略的文件或者说精灵的正则表达式。格式：new RegExp(string)中string的格式。注意:"\"这个符号在配置文件中需要写两次。生成“帧动画定义文件”要忽略的文件或者说精灵的正则表达式。
        "Format": 1,							# 帧动画文件格式。1|2|"auto"。
        "FileName" : "animation.plist"          # 生成的"帧动画定义文件"的文件名。
    }
}