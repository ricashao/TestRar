"""

"""

import re

__all__ = ["FlashImageTextureDef", "ZwoptexImageTextureDef", "ImageTextureDef"]


class FlashImageTextureDef():
    """ flash格式的图像纹理定义文件处理代码。
    """

    def __init__(self):
        self._data = None #plist 文件中根<dict>节点数据。

    def setData(self, data):
        """ 设置数据
        """
        self._data = data

    def getFormat(self):
        """ 返回 plist 图像纹理定义格式。
            @returns {int}
        """
        return 0

    def getFrames(self):
        """ 返回帧集合。
            @returns {list}
        """
        return self._data["frames"]

    def getMatchAnimations(self):
        """ 推导并且返回动画名与其对应的帧列表。
            @return {{}} {animationName:[1,2,3,...],...};
        """
        import coolPlist
        animations = {};
        for key, _ in self.getFrames().items():
            animationName = coolPlist.inferToAnimationName(key);
            ignore = False;
            if coolPlist.getIgnoreFramesRegexp() != None :
                # print((new RegExp(coolPlist.ignoreFramesRegexp, "g")).toString());
                ignore = re.search(re.compile(coolPlist.getIgnoreFramesRegexp()), key) != None;
            
            frameIndex = coolPlist.inferToFrameIndex(key);
            if animationName != None and frameIndex != -1 and not ignore:
                if animationName not in animations:
                    animations[animationName] = []
                animations[animationName].append(key);
        return animations;

    def getMetadata(self):
        """ 返回元数据。在格式format0中是没有这个metadata的，所以，此方法永远返回None。
            @returns {{}}
        """
        return None


class ZwoptexImageTextureDef():
    """ Zwoptex 工具生成的图像纹理定义文件格式处理代码。
    """

    def __init__(self):
        self._data = None

    def setData(self, data):
        self._data = data

    def getFormat(self):
        """ 返回 plist 图像纹理定义格式。
     	    @returns {number}
        """
        return self.getMetadata()["format"];
        
    def getFrames(self):
        """ 返回帧集合。
            @returns {list}
        """
        return self._data["frames"]

    def getMatchAnimations(self):
        """ 推导并且返回动画名与其对应的帧列表。
     	    @return {{}} {animationName:[1,2,3,...],...};
        """
        import coolPlist
        animations = {};
        # 将图片纹理定义文件中的符合作为动画帧的图片添加为对应动画的动画帧。
        for key, _ in self.getFrames().items() :
            animationName = coolPlist.inferToAnimationName(key);
            ignore = False;
            if coolPlist.getIgnoreFramesRegexp() != None :
                # print((new RegExp(coolPlist.ignoreFramesRegexp, "g")).toString());
                ignore = re.search(re.compile(coolPlist.getIgnoreFramesRegexp()), key) != None;
            
            frameIndex = coolPlist.inferToFrameIndex(key);
            if animationName != None and frameIndex != -1 and not ignore:
                if animationName not in animations:
                    animations[animationName] = []
                animations[animationName].append(key);
            
        return animations;

    def getMetadata(self):
        """ 返回元数据。
     		@returns {{}}
        """
        return self._data["metadata"]


class ImageTextureDef():
    """ 图像纹理定义
    """
    # format0 = FlashImageTextureDef()      # 代表Flash版本；

    # format1 = ZwoptexImageTextureDef()    #Zwoptex 0.4b以前支持；

    # format2 = ZwoptexImageTextureDef()    #Zwoptex 1.0以后支持，与format1的区别在于支持旋转；

    # format3 = ZwoptexImageTextureDef()    #属性名称进行了大幅修改，Zwoptes1.0.2之后支持。
        
        
    @classmethod
    def getFormat(cls, plistData):
        """ 从 plist 文件(图像纹理定义文件)读取的数据。
     	    @param {Object} plistData
     	    @return {int}
        """
        # print("ImageTextureDef getFormat() plistData = ")
        # print(plistData)
        # flash格式的格式值为0
        if ("texture" in plistData) and plistData["texture"] != None:
            return 0
        # Zwoptex工具生成的取其自带的格式值。
        elif plistData["metadata"]:
            return plistData["metadata"]["format"]
        return -1

    @classmethod
    def getFormatProxy(cls, format):
        # print(format)
        if format == 0:
            return FlashImageTextureDef()      # 代表Flash版本；
        elif format == 1:
            return ZwoptexImageTextureDef()    #Zwoptex 0.4b以前支持；
        elif format == 2:
            return ZwoptexImageTextureDef()    #Zwoptex 1.0以后支持，与format1的区别在于支持旋转；
        elif format == 3:
            return ZwoptexImageTextureDef()    #属性名称进行了大幅修改，Zwoptes1.0.2之后支持。