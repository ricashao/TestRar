"""
    本模块主要提供多种 “帧动画定义文件” 内容的生成代码
"""
import plistlib
import os


__all__ = ["FrameAnimationFormat1", "FrameAnimationFormat2"]

class FrameAnimationFormat1():
    """ 帧动画定义文件格式1。
        格式示例：
                <?xml version="1.0" encoding="utf-8"?>
                <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"[]>
                <plist version="1.0">
                    <dict>
                        <key>animations</key>
                        <dict>
                            <key>dance_1</key>
                            <dict>
                                <key>delay</key>
                                <real>0.2</real>
                                <key>frames</key>
                                <array>
                                <string>grossini_dance_01.png</string>
                                <string>grossini_dance_02.png</string>
                                <string>grossini_dance_03.png</string>
                                ...
                                </array>
                            </dict>
                        </dict>
                    </dict>
                 </plist>
    """

    def __init__(self):
        self._data = {
            "animations": {}
        }

    def imageTextureDefPlistToAnimation(self, spritesheet):
        """ 根据图片纹理配置文件推导出动画数据，并添加到当前。
            @param {String|file} spritesheet "精灵表单"也即是"图像纹理定义"文件名称。
        """
        result = False
        plistFileName = spritesheet
        # 文本状态下则视为文件路径。
        if isinstance(spritesheet, str):
            data = plistlib.readPlist(plistFileName)
        # 文件状态下则视为配置文件的引用。
        else:
            data = plistlib.load(spritesheet)
        
        if data == None :
            return result
        from utils.imageTextureDef import ImageTextureDef
        format = ImageTextureDef.getFormat(data)
        isNotImageTextureDefFile = (format == -1)
        if isNotImageTextureDefFile:
            return result
        
        formatProxy = ImageTextureDef.getFormatProxy(format)
        formatProxy.setData(data)
        animations = formatProxy.getMatchAnimations()
        for animationName, frames in animations.items():
            self.addAnimation(animationName, None, frames)
            result = True
        
        return result

    def plistFolderToAnimation(self, folder):
        """ 从plist文件夹中取得 plist 文件中符合作为动画的内容。
            @param {String} folder 
        """
        import coolPlist
        if isinstance(folder, str):
            for dirpath, dirnames, filenames in os.walk(folder):
                for filename in filenames:
                    fullpath = os.path.join(dirpath, filename)
                    if coolPlist.isPlistFileType(filename):
                        self.addSpritesheet(fullpath)
        else:
            raise TypeError("参数 folder 必须是目录路径")
        

    def folderToAnimation(self, folder):
        """ 分析指定目录中的图片文件并根据其命名规则，自动识别图片所属动画，并属于哪一帧，然后添加到帧动画定义文件数据中。
            @param {String} folder 
        """
        import coolPlist
        # 使用文件夹名称作为动画名称。
        if coolPlist.isAnimationUseFolderName() :
            # 此模式下将视同目录所有图片文件（哪怕使用不同命名规则）为同一个动画的帧。
            # 即一个目录为一个动画。
            for dirpath, dirnames, filenames in os.walk(folder):
                animationName = os.path.basename(dirpath)
                print("-----------add Animation '" + animationName + "'-----------")
                frames = []
                for filename in filenames:
                    # fullpath = os.path.join(dirpath, filename)
                    if coolPlist.isSupportedFileType(filename) and coolPlist.isAnimationSprite(filename) :
                        print("-- add Frame '" + filename + "'")
                        frames.append(self.fileToFrame(filename));
                self.addAnimation(animationName, None, frames)
                print("----------------------------------------")
        else : # 自动分析同一目录下的图片文件名称，根据不同的命名规则区分图片是属于哪一个动画。
            for dirpath, dirnames, filenames in os.walk(folder):
                animations = {}
                frames = []
                for filename in filenames:
                    # fullpath = os.path.join(dirpath, filename)
                    # print("coolPlist.isSupportedFileType(filename) = ", coolPlist.isSupportedFileType(filename))
                    # print("coolPlist.isAnimationSprite(filename) = ", coolPlist.isAnimationSprite(filename))
                    if coolPlist.isSupportedFileType(filename) and coolPlist.isAnimationSprite(filename) :
                        animationName = coolPlist.inferToAnimationName(filename)
                        if animationName not in animations:
                            animations[animationName] = []
                        animations[animationName].append(self.fileToFrame(filename))
                for animationName in animations:
                    frames = animations[animationName]
                    self.addAnimation(animationName, None, frames)

    def fileToFrame(self, file):
        """ 根据文件名获取帧名称。
            @param {String} file 
            @return {String}
        """
        return file

    def addSpritesheet(self, spritesheet):
        """ 尝试添加一个精灵表单。
            @param {String} spritesheet plist 文件的完整文件名。
        """
        self.imageTextureDefPlistToAnimation(spritesheet)
        
    def addFrame(self, animationName, spriteframe):
        """
            @param {String} animationName
            @param {String} spriteframe 帧名称。（其实就是文件名）
        """
        animation = self.getAnimation(animationName)
        animation["frames"].append(spriteframe)

    def addAnimation(self, animationName, delay, frames):
        """ 添加一个动画。
            @param {String} animationName
            @param {number} [delay] 
            @param {Array} [frames] 数据格式["frameName", ...]
        """
        animation = self.createAnimation(delay, frames)
        self._data["animations"][animationName] = animation
    
    def appendAnimation(self, animationName, animiation):
        """ 追加一个动画数据.
            @param animationName
            @param animiation 
        """
        animations = self._data["animations"]
        animations[animationName] = animation

    def hasAnimation(self, animationName):
        """
            @param animationName
            @return {Boolean} 
        """
        return animationName in self._data["animations"]

    def getAnimation(self, animationName):
        """ 获取
            @param {String} animationName
        """
        animation = self._data["animations"][animationName]
        if animation == None :
            self.addAnimation(animationName)
        
        
    def createAnimation(self, delay, frames):
        """
            @param {Number} [delay] 延迟秒数。
             @param {Array} [frames]
        """
        import coolPlist
        delay = 1000/60/1000 if delay == None else delay
        frames = [] if frames == None else frames
        coolPlist.frameSort(frames)
        animation = {
            "delay":delay,
            "frames" : frames
        }
        return animation



class FrameAnimationFormat2():
    """ “帧动画定义文件”format 2 格式的加法。
        格式示例：
        <?xml version="1.0" encoding="utf-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"[]>
        <plist version="1.0">
            <dict>
                <key>animations</key>
                <dict>
                <key>dance_1</key>
                <dict>
                    <key>delayPerUnit</key>
                    <real>0.2</real>
                    <key>restoreOriginalFrame</key>
                    <true />
                    <key>loops</key>
                    <integer>2</integer>
                    <key>frames</key>
                    <array>
                    <dict>
                        <key>spriteframe</key>
                        <string>grossini_dance_01.png</string>
                        <key>delayUnits</key>
                        <integer>1</integer>
                        <key>notification</key>
                        <dict>
                        <key>firstframe</key>
                        <true />
                        </dict>
                    </dict>
                    <dict>
                        <key>spriteframe</key>
                        <string>grossini_dance_02.png</string>
                        <key>delayUnits</key>
                        <integer>1</integer>
                    </dict>
                    <dict>
                        <key>spriteframe</key>
                        <string>grossini_dance_03.png</string>
                        <key>delayUnits</key>
                        <integer>1</integer>
                        <key>notification</key>
                        <dict>
                        <key>key1</key>
                        <integer>1234</integer>
                        <key>key2</key>
                        <false />
                        </dict>
                    </dict>
                    </array>
                </dict>
                </dict>
                <key>properties</key>
                <dict>
                <key>spritesheets</key>
                <array>
                    <string>animations/grossini.plist</string>
                </array>
                <key>format</key>
                <integer>2</integer>
                </dict>
            </dict>
        </plist>
        * @type {{_data: None, init: _fAnimationFormat2.init, addFrame: _fAnimationFormat2.addFrame, addAnimation: _fAnimationFormat2.addAnimation, getAnimation: _fAnimationFormat2.getAnimation, createAnimation: _fAnimationFormat2.createAnimation, createFrame: _fAnimationFormat2.createFrame}}
        * @private
    """

    def __init__(self) :
        """ 初始化。
        """
        self._data = {
            "animations" : {
                # 动态添加。
            },
            "properties" : {
                "spritesheets":[], # 示例：["animations/grossini.plist","animations/grossini_blue.plist",...]
                "format" : 2
            }
        }


    def imageTextureDefPlistToAnimation(self, spritesheet) :
        """ 根据图片纹理配置文件推导出动画数据，并添加到当前。
            @param {String|file} spritesheet "精灵表单"也即是"图像纹理定义"文件名称。
            @return {Boolean} 成功或者失败。
        """
        result = False
        plistFile = spritesheet
        if isinstance(spritesheet, str):
            data = plistlib.readPlist(plistFile)
        else :
            data = plistlib.load(spritesheet)
        
        if data == None:
            return result
        from utils.imageTextureDef import ImageTextureDef
        format = ImageTextureDef.getFormat(data)
        isNotImageTextureDefFile = (format == -1)
        if isNotImageTextureDefFile:
            return result
        
        formatProxy = ImageTextureDef.getFormatProxy(format)
        formatProxy.setData(data)
        animations = formatProxy.getMatchAnimations()
        for animationName, frames in animations.items():
            frames = self.createFrames(frames)
            self.addAnimation(animationName, None, None, None, frames)
            result = True
        return result

    def plistFolderToAnimation (self, folder):
        """ 从plist文件夹中取得 plist 文件中符合作为动画的内容。
            @param {string} folder 
        """
        import coolPlist
        if isinstance(folder, str):
            for dirpath, dirnames, filenames in os.walk(folder):
                for filename in filenames:
                    fullpath = os.path.join(dirpath, filename)
                    if coolPlist.isPlistFileType(filename):
                        self.addSpritesheet(fullpath)
        else:
            raise TypeError("参数 folder 必须是目录路径")

    def folderToAnimation (self, folder):
        """ 将文件夹中符合作为动画的图片文件添加到当前动画配置中去。
            @param {String} folder 
        """
        from coolPlist import isAnimationUseFolderName
        from coolPlist import isAnimationSprite
        from coolPlist import isSupportedFileType
        from coolPlist import inferToAnimationName
        
        # 使用文件夹名称作为动画名称。
        if isAnimationUseFolderName():
            # 此模式下将视同目录所有图片文件（哪怕使用不同命名规则）为同一个动画的帧。
            # 一个目录即一个动画。
            
            for dirpath, dirnames, filenames in os.walk(folder):
                animationName = os.path.basename(dirpath)
                print("-----------add Animation '" + animationName + "'-----------")
                frames = []
                for filename in filenames:
                    # fullpath = os.path.join(dirpath, filename)
                    if isSupportedFileType(filename) and isAnimationSprite(filename) :
                        print("-- add Frame '" + filename + "'")
                        frames.append(self.fileToFrame(filename));
                self.addAnimation(animationName, None, None, None, frames)
                print("----------------------------------------")
        else: # 自动分析同一目录下的图片文件名称，根据不同的命名规则区分图片是属于哪一个动画。
            for dirpath, dirnames, filenames in os.walk(folder):
                animations = {}
                frames = []
                for filename in filenames:
                    # fullpath = os.path.join(dirpath, filename)
                    if isSupportedFileType(filename) and isAnimationSprite(filename) :
                        animationName = inferToAnimationName(filename)
                        if animationName not in animations:
                            animations[animationName] = []
                    animations[animationName].append(self.fileToFrame(filename))
                for animationName in animations:
                    frames = animations[animationName]
                    self.addAnimation(animationName, None, None, None, frames)

    def fileToFrame(self, file):
        """ 
            @param {String} file 
            @return {Object} 
        """
        return  self.createFrame(file)

    def addSpritesheet(self, spritesheet): 
        """ 尝试添加一个精灵表单。
            @param {String} spritesheet plist 文件的完整文件名。
            @return {Boolean} 添加成功或者失败。
        """
        if not isinstance(spritesheet, str):
            raise TypeError("参数 spritesheet 必须是字符串！")
        success = self.imageTextureDefPlistToAnimation(spritesheet)
        if success:
            self._data["properties"]["spritesheets"].append(spritesheet) # 示例：["animations/grossini.plist","animations/grossini_blue.plist",...]

    def addFrame(self, animationName, spriteframe, delayUnits = 1, notification = None):
        """ 创建一个帧。
            @param {String} animationName
            @param {String} spriteframe
            @param {Number} [delayUnits] 默认值是1。
            @param {Object} [notification] 这个一般情况下不用。
        """
        animation = self.getAnimation(animationName)
        animation["frames"].append(self.createFrame(spriteframe, delayUnits))

    def addAnimation(self, animationName, delayPerUnit, restoreOriginalFrame, loops, frames) :
        """
            @param {String} animationName
            @param {Number} delayPerUnit
            @param {Boolean} restoreOriginalFrame
            @param {Boolean} loops
            @param {Array} [frames]
            @private
        """
        animations = self._data["animations"]
        if animationName in animations:
            # WScript.Echo(animationName)
            print("[Warning] : 动画 " + animationName + " 重复创建 ")
            return 
        
        animation = self.createAnimation(delayPerUnit, restoreOriginalFrame, loops, frames)
        animations[animationName] = animation

    def appendAnimation(self, animationName, animiation) :
        """ 追加一个动画数据.
            @param animationName
            @param animiation
        """
        animations = self._data["animations"]
        animations[animationName] = animation

    def getAnimation(self, animationName):
        """ 返回一个动画数据。
            @param {String} animationName
        """
        animation = self._data["animations"][animationName]
        if animation == None:
            animation = self.createAnimation()
            self._data["animations"][animationName] = animation
        
        return animation

    def createAnimation(self, delayPerUnit = 1000/60/1000, restoreOriginalFrame = True, loops = 1, frames = []):
        """ @param {Number} [delayPerUnit] 定义的就是每帧之间的间隔
            @param {Boolean} [restoreOriginalFrame]
            @param {int} [loops]
            @param {Array} [frames]
            @returns {{delayPerUnit: *, restoreOriginalFrame: *, loops: *, frames: Array}}
        """
        import coolPlist
        coolPlist.frameSort(frames)
        delayPerUnit = delayPerUnit if delayPerUnit != None else 1000/60/1000
        restoreOriginalFrame = restoreOriginalFrame if restoreOriginalFrame != None else True
        loops = loops if loops != None else 1
        animation = {
            "delayPerUnit":delayPerUnit,
            "restoreOriginalFrame" : restoreOriginalFrame,
            "loops" : loops,
            "frames" : frames
        }
        return animation

    def createFrame(self, spriteframe, delayUnits = 1, notification = None):
        """ 创建一个帧。
            @param {String} spriteframe 帧名称。
            @param {Number} [delayUnits] 定义了每帧的延迟值，它会覆盖 delayPerUnit 的定义。实际上，动画持续的时间，就是 所有帧的 delayUnits 的和乘以 delayPerUnit 。
            @param {Object} [notification]
        """
        frame  = {}
        frame["spriteframe"] = spriteframe 
        frame["delayUnits"] = delayUnits if delayUnits != None else 1
        if notification:
            frame["notification"] = notification 
        
        return frame


    def createFrames(self, frameNames):
        """ 根据一个帧名称列表创建一个动画帧数据列表。
            @param {Array} frameNames [(String), ...]
        """
        frames = []
        for frameName in frameNames:
            frames.append(self.createFrame(frameName))
        return frames

